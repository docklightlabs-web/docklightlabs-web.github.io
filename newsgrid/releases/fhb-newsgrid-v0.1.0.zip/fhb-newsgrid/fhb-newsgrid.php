<?php
/**
 * Plugin Name: FloridaHillbilly NewsGrid
 * Description: Serves locally generated current-events crossword editions as an anonymous game.
 * Version: 0.1.0
 * Author: DockLight Labs
 */
defined( 'ABSPATH' ) || exit;

const FHB_NEWSGRID_OPTION = 'fhb_newsgrid_issue_json';

function fhb_newsgrid_validate_issue( $raw ) {
    if ( ! is_string( $raw ) || strlen( $raw ) > 65536 ) {
        return new WP_Error( 'newsgrid_payload', 'Issue must be a JSON string of at most 64 KiB.' );
    }
    $issue = json_decode( $raw, true );
    if ( ! is_array( $issue ) || ! isset( $issue['date'], $issue['grid'], $issue['rows'], $issue['cols'], $issue['entries'] ) ) {
        return new WP_Error( 'newsgrid_format', 'Missing issue fields.' );
    }
    if ( ! is_string( $issue['date'] ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/D', $issue['date'] ) ||
         ! isset( $issue['displayDate'], $issue['generatedAt'], $issue['topic'] ) ||
         ! is_string( $issue['displayDate'] ) || strlen( $issue['displayDate'] ) > 100 ||
         ! is_string( $issue['generatedAt'] ) || strlen( $issue['generatedAt'] ) > 80 ||
         ! is_string( $issue['topic'] ) || strlen( $issue['topic'] ) > 80 ) {
        return new WP_Error( 'newsgrid_metadata', 'Invalid issue metadata.' );
    }
    $rows = $issue['rows'];
    $cols = $issue['cols'];
    $grid = $issue['grid'];
    if ( ! is_int( $rows ) || ! is_int( $cols ) || $rows < 3 || $rows > 25 || $cols < 3 || $cols > 25 ||
         ! is_array( $grid ) || count( $grid ) !== $rows ) {
        return new WP_Error( 'newsgrid_geometry', 'Invalid puzzle dimensions.' );
    }
    foreach ( $grid as $row ) {
        if ( ! is_array( $row ) || count( $row ) !== $cols ) {
            return new WP_Error( 'newsgrid_geometry', 'Invalid row.' );
        }
        foreach ( $row as $cell ) {
            if ( ! is_string( $cell ) || ( '' !== $cell && ! preg_match( '/^[A-Z]$/D', $cell ) ) ) {
                return new WP_Error( 'newsgrid_geometry', 'Invalid letter.' );
            }
        }
    }
    if ( ! is_array( $issue['entries'] ) || count( $issue['entries'] ) < 7 || count( $issue['entries'] ) > 25 ) {
        return new WP_Error( 'newsgrid_entries', 'Invalid clue count.' );
    }
    foreach ( $issue['entries'] as $entry ) {
        if ( ! is_array( $entry ) || ! isset( $entry['row'], $entry['col'], $entry['direction'], $entry['length'],
                                           $entry['answer'], $entry['clue'], $entry['url'],
                                           $entry['number'], $entry['title'], $entry['source'] ) ||
             ! is_int( $entry['row'] ) || ! is_int( $entry['col'] ) || ! is_int( $entry['length'] ) ||
             ! is_int( $entry['number'] ) || $entry['number'] < 1 || $entry['number'] > 25 ||
             ! in_array( $entry['direction'], array( 'A', 'D' ), true ) ||
             ! is_string( $entry['answer'] ) || $entry['length'] !== strlen( $entry['answer'] ) ||
             $entry['length'] < 3 || $entry['length'] > 15 ||
             ! is_string( $entry['clue'] ) || strlen( $entry['clue'] ) > 500 ||
             ! is_string( $entry['title'] ) || strlen( $entry['title'] ) > 500 ||
             ! is_string( $entry['source'] ) || strlen( $entry['source'] ) > 500 ||
             ! is_string( $entry['url'] ) || strlen( $entry['url'] ) > 2048 ||
             'https' !== wp_parse_url( $entry['url'], PHP_URL_SCHEME ) ||
             'news.google.com' !== strtolower( (string) wp_parse_url( $entry['url'], PHP_URL_HOST ) ) ) {
            return new WP_Error( 'newsgrid_entry', 'Invalid source or clue.' );
        }
        for ( $i = 0; $i < $entry['length']; $i++ ) {
            $r = $entry['row'] + ( 'D' === $entry['direction'] ? $i : 0 );
            $c = $entry['col'] + ( 'A' === $entry['direction'] ? $i : 0 );
            if ( $r < 0 || $r >= $rows || $c < 0 || $c >= $cols ||
                 $grid[$r][$c] !== $entry['answer'][$i] ) {
                return new WP_Error( 'newsgrid_cross', 'Entry does not match solution grid.' );
            }
        }
    }
    return $issue;
}
function fhb_newsgrid_sanitize_setting( $raw ) {
    $checked = fhb_newsgrid_validate_issue( $raw );
    if ( is_wp_error( $checked ) ) {
        add_settings_error( FHB_NEWSGRID_OPTION, $checked->get_error_code(), $checked->get_error_message(), 'error' );
        return get_option( FHB_NEWSGRID_OPTION, '' );
    }
    return $raw;
}
add_action( 'rest_api_init', function () {
    register_setting( 'general', FHB_NEWSGRID_OPTION, array(
        'type' => 'string',
        'show_in_rest' => true,
        'default' => '',
        'sanitize_callback' => 'fhb_newsgrid_sanitize_setting',
    ) );
} );
add_shortcode( 'fhb_newsgrid', function () {
    $raw = get_option( FHB_NEWSGRID_OPTION, '' );
    $checked = fhb_newsgrid_validate_issue( $raw );
    if ( is_wp_error( $checked ) ) {
        return '<p>NewsGrid is preparing the next edition. Please check back shortly.</p>';
    }
    wp_register_script(
        'fhb-newsgrid',
        plugins_url( 'assets/newsgrid.js', __FILE__ ),
        array(),
        '0.1.0',
        true
    );
    wp_enqueue_script( 'fhb-newsgrid' );
    wp_add_inline_script(
        'fhb-newsgrid',
        'window.fhbNewsGridIssue=' . wp_json_encode( $checked, JSON_HEX_TAG | JSON_HEX_AMP |
                                     JSON_HEX_APOS | JSON_HEX_QUOT ) . ';',
        'before'
    );
    return '<div id="fhb-newsgrid-embed" aria-label="NewsGrid current events crossword"></div>';
} );
