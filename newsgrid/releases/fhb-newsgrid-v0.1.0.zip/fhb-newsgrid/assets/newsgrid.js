
(()=>{"use strict";
const mount=window.document.getElementById("fhb-newsgrid-embed");if(!mount)return;const root=mount.attachShadow({mode:"open"});const document={querySelector:s=>root.querySelector(s),querySelectorAll:s=>root.querySelectorAll(s),createTextNode:s=>window.document.createTextNode(s)};root.innerHTML="\u003cstyle\u003e:host{display:block;color:#151515;font-family:Georgia,serif}\n:root{--bg:#f5f2ea;--paper:#fffdf7;--ink:#151515;--muted:#6c6a64;--line:#d5d0c5;--accent:#1f5f46;--accent2:#dce9df;--bad:#a43b33;--good:#2c7b4f}\n*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:Georgia,\"Times New Roman\",serif}\n.shell{max-width:1180px;margin:0 auto;padding:24px 18px 60px}\n.topbar{display:flex;justify-content:space-between;gap:20px;align-items:flex-end;border-bottom:3px solid var(--ink);padding-bottom:12px}\n.brand{font-family:Arial,sans-serif;font-weight:900;font-size:clamp(28px,5vw,54px);letter-spacing:-2px}.brand span{color:var(--accent)}\n.kicker,.date,.meta,.eyebrow{font-family:Arial,sans-serif;text-transform:uppercase;letter-spacing:.12em;font-size:12px;color:var(--muted)}\n.hero{padding:24px 0 18px}.hero h1{font-size:clamp(28px,5vw,50px);margin:5px 0 6px;line-height:1}.hero p{margin:0;color:var(--muted);font-size:18px}\n.generator{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0 0 18px;padding:14px;border:1px solid var(--line);background:var(--paper)}\n.generator input{flex:1;min-width:220px;padding:11px 12px;border:1px solid var(--line);font:15px Arial,sans-serif}.generator .gen-status{font:700 12px Arial,sans-serif;color:var(--muted)}\n.ad{border:1px solid var(--line);background:#ece9e1;min-height:86px;display:flex;align-items:center;justify-content:center;margin:10px 0 24px;font-family:Arial,sans-serif;color:#8a877f;font-size:11px;letter-spacing:.18em}\n.layout{display:grid;grid-template-columns:minmax(320px,680px) minmax(280px,1fr);gap:28px;align-items:start}\n.panel{background:var(--paper);border:1px solid var(--line);box-shadow:0 8px 28px rgba(0,0,0,.05)}\n.puzzle-wrap{padding:16px}.grid{display:grid;background:#111;border:2px solid #111;gap:1px;max-width:680px;aspect-ratio:1/1}\n.cell{position:relative;background:#fff;min-width:0;min-height:0}.cell.block{background:#111}\n.cell input{width:100%;height:100%;border:0;outline:0;text-align:center;text-transform:uppercase;font-family:Arial,sans-serif;font-weight:800;font-size:clamp(13px,2.2vw,28px);background:transparent;padding:0}\n.cell .num{position:absolute;left:2px;top:1px;font:700 clamp(7px,.9vw,10px)/1 Arial,sans-serif;z-index:2}\n.cell.active{background:#fff1a8}.cell.correct{background:#dff1e7}.cell.wrong{background:#f6d8d5}\n.controls{display:flex;flex-wrap:wrap;gap:8px;padding:14px 16px 16px;border-top:1px solid var(--line)}\nbutton,.button{border:1px solid var(--ink);background:var(--ink);color:#fff;padding:10px 14px;font:700 13px Arial,sans-serif;cursor:pointer;text-decoration:none}\nbutton.secondary{background:transparent;color:var(--ink)}button:hover,.button:hover{opacity:.88}\n.progress{margin-left:auto;align-self:center;font:700 12px Arial,sans-serif;color:var(--muted)}\n.clues{padding:18px}.clues h2{font:900 18px Arial,sans-serif;margin:0 0 10px;border-bottom:2px solid var(--ink);padding-bottom:8px}\n.clue{padding:10px 0;border-bottom:1px solid var(--line)}\n.clue button{display:block;width:100%;text-align:left;border:0;background:transparent;color:var(--ink);padding:0;font:700 15px/1.35 Georgia,serif}\n.clue button:hover{text-decoration:underline}.headline{display:block;margin-top:5px;font:700 11px/1.35 Arial,sans-serif;color:var(--accent)}\n.read-article{display:inline-block;margin-top:8px;padding:7px 10px;border:1px solid var(--accent);font:800 11px Arial,sans-serif;color:var(--accent);text-decoration:none}\n.read-article:hover{background:var(--accent);color:#fff}.source-name{color:var(--muted);font-weight:400}\n.signup{margin-top:24px;padding:18px;background:var(--accent);color:#fff}.signup h3{font:900 22px Arial,sans-serif;margin:0 0 6px}.signup p{margin:0 0 12px;color:#e9f3ec}\n.signup form{display:flex;gap:8px}.signup input{flex:1;min-width:0;padding:11px;border:0;font-size:16px}.signup button{background:#fff;color:var(--accent);border-color:#fff}\n.status{font:700 12px Arial,sans-serif;margin-top:8px}.footer{margin-top:34px;border-top:1px solid var(--line);padding-top:14px;font:12px Arial,sans-serif;color:var(--muted);display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}\n.loading{padding:40px;font:700 16px Arial,sans-serif}\n@media(max-width:820px){.layout{grid-template-columns:1fr}.topbar{align-items:flex-start;flex-direction:column}.progress{margin-left:0}.clues{padding:14px}}\n\u003c/style\u003e\u003cdiv class=\"shell\"\u003e\n\u003cheader class=\"topbar\"\u003e\n  \u003cdiv\u003e\u003cdiv class=\"kicker\"\u003eDocklight Labs\u003c/div\u003e\u003cdiv class=\"brand\"\u003eNEWS\u003cspan\u003eGRID\u003c/span\u003e\u003c/div\u003e\u003c/div\u003e\n  \u003cdiv class=\"date\" id=\"date\"\u003eLoading today’s puzzle…\u003c/div\u003e\n\u003c/header\u003e\n\u003csection class=\"hero\"\u003e\n  \u003cdiv class=\"eyebrow\"\u003eThe daily news crossword\u003c/div\u003e\n  \u003ch1\u003eSolve the day. Follow the story.\u003c/h1\u003e\n  \u003cp\u003eEvery clue comes from a real headline. Stuck—or curious? Open the story.\u003c/p\u003e\n\u003c/section\u003e\n\u003cdiv id=\"app\" class=\"loading\"\u003eBuilding the grid…\u003c/div\u003e\n\u003cdiv class=\"signup\"\u003e\u003ch3\u003eMore FloridaHillbilly?\u003c/h3\u003e\u003cp\u003eVisit our existing subscription page for general site updates.\u003c/p\u003e\u003ca class=\"button\" href=\"https://floridahillbilly.com/subscribe/\"\u003eSubscription page\u003c/a\u003e\u003c/div\u003e\n\u003cfooter class=\"footer\"\u003e\u003cspan\u003eNewsGrid · FloridaHillbilly\u003c/span\u003e\u003cspan\u003eClues are generated from current headlines and link back to the source.\u003c/span\u003e\u003c/footer\u003e\n\u003c/div\u003e\n";
const ISSUE=window.fhbNewsGridIssue;
function safeNewsURL(raw){try{const u=new URL(raw);return u.protocol==="https:"?u.href:"#"}catch{return "#"}}

let puzzle=null,state={},cellMap=new Map(),activeKey=null,lastTappedCell=null;
const $=s=>document.querySelector(s);
const key=(r,c)=>`${r}:${c}`;
const entryCells=e=>Array.from({length:e.length},(_,i)=>[e.row+(e.direction==="D"?i:0),e.col+(e.direction==="A"?i:0)]);
function storageKey(){return "newsgrid:"+(puzzle.generatedAt||puzzle.date)}
function loadState(){try{return JSON.parse(localStorage.getItem(storageKey())||"{}")}catch{return {}}}
function saveState(){localStorage.setItem(storageKey(),JSON.stringify(state))}
function render(){
  $("#date").textContent=puzzle.topic?(puzzle.topic+" · "+puzzle.displayDate):puzzle.displayDate;
  const starts={}; for(const e of puzzle.entries){starts[key(e.row,e.col)]=e.number}
  const cells=puzzle.grid.map((row,r)=>row.map((ch,c)=>{
    if(!ch)return `<div class="cell block"></div>`;
    const k=key(r,c), n=starts[k]||"";
    return `<div class="cell" data-key="${k}">${n?`<span class="num">${n}</span>`:""}<input maxlength="1" inputmode="text" aria-label="row ${r+1} column ${c+1}" data-r="${r}" data-c="${c}" value="${escapeAttr(state[k]||"")}"></div>`;
  }).join("")).join("");
  const across=puzzle.entries.filter(e=>e.direction==="A").sort((a,b)=>a.number-b.number);
  const down=puzzle.entries.filter(e=>e.direction==="D").sort((a,b)=>a.number-b.number);
  const clueHTML=list=>list.map(e=>`<div class="clue">
    <button class="entry-jump" data-entry="${e.number}${e.direction}">
      <span>${e.number}. ${escapeHTML(e.clue)} <span class="source-name">(${e.length})</span></span>
      <span class="headline">${escapeHTML(e.title)}</span>
    </button>
    <a class="read-article" href="${escapeAttr(safeNewsURL(e.url))}" target="_blank" rel="noopener">Read article ↗</a>
  </div>`).join("");
  $("#app").className="layout";
  $("#app").innerHTML=`<section class="panel"><div class="puzzle-wrap"><div class="grid" style="grid-template-columns:repeat(${puzzle.cols},1fr);grid-template-rows:repeat(${puzzle.rows},1fr)">${cells}</div></div>
    <div class="controls"><button id="check">Check</button><button id="clearWrong" class="secondary">Clear wrong</button><button id="share" class="secondary">Share</button><span class="progress" id="progress"></span></div></section>
    <aside class="panel clues"><h2>Across</h2>${clueHTML(across)}<h2 style="margin-top:20px">Down</h2>${clueHTML(down)}</aside>`;
  cellMap=new Map([...document.querySelectorAll(".cell[data-key]")].map(x=>[x.dataset.key,x]));
  document.querySelectorAll(".cell input").forEach(inp=>{inp.addEventListener("input",onInput);inp.addEventListener("click",onCellClick)});
  document.querySelectorAll(".clue button").forEach(btn=>btn.addEventListener("click",()=>selectEntry(btn.dataset.entry)));
  $("#check").addEventListener("click",check);
  $("#clearWrong").addEventListener("click",clearWrong);
  $("#share").addEventListener("click",share);
  updateProgress();
}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function escapeAttr(s){return escapeHTML(s)}
const entryID=e=>`${e.number}${e.direction}`;
const entriesForCell=(r,c)=>puzzle.entries.filter(e=>entryCells(e).some(([rr,cc])=>rr===r&&cc===c));
function highlightEntry(e){
  if(!e)return;
  activeKey=entryID(e);
  document.querySelectorAll(".cell").forEach(x=>x.classList.remove("active"));
  for(const [r,c] of entryCells(e))cellMap.get(key(r,c))?.classList.add("active");
}
function onCellClick(ev){
  const r=+ev.currentTarget.dataset.r,c=+ev.currentTarget.dataset.c,k=key(r,c);
  const matches=entriesForCell(r,c);
  if(!matches.length)return;
  const selected=matches.find(e=>entryID(e)===activeKey);
  // Tap an intersection a second time to change direction deliberately.
  const entry=lastTappedCell===k&&selected&&matches.length>1
    ? matches.find(e=>e!==selected)
    : selected||matches.find(e=>e.direction==="A")||matches[0];
  lastTappedCell=k;
  highlightEntry(entry);
}
function onInput(ev){
  const i=ev.target,r=+i.dataset.r,c=+i.dataset.c;
  i.value=i.value.toUpperCase().replace(/[^A-Z]/g,"").slice(-1);
  const k=key(r,c);state[k]=i.value;saveState();updateProgress();
  if(i.value){
    const entry=findEntryForCell(r,c);
    if(entry){highlightEntry(entry);advance(entry,r,c)}
  }
}
function findEntryForCell(r,c){
  const matches=entriesForCell(r,c);
  // Keep the selected word at a crossing; default to Across on a fresh cell.
  return matches.find(e=>entryID(e)===activeKey)
    ||matches.find(e=>e.direction==="A")||matches[0]||null;
}
function advance(e,r,c){
  const cells=entryCells(e),idx=cells.findIndex(([rr,cc])=>rr===r&&cc===c);
  const next=cells[idx+1];if(!next)return;const el=cellMap.get(key(...next))?.querySelector("input");if(el)el.focus()
}
function selectEntry(id){
  const e=puzzle.entries.find(x=>entryID(x)===id);if(!e)return;
  lastTappedCell=null;
  highlightEntry(e);
  const start=cellMap.get(key(e.row,e.col))?.querySelector("input");
  start?.focus();
  document.querySelector(".puzzle-wrap")?.scrollIntoView({behavior:"smooth",block:"start"});
}
function check(){
  let all=true,correct=0,total=0;
  for(let r=0;r<puzzle.rows;r++)for(let c=0;c<puzzle.cols;c++){const sol=puzzle.grid[r][c];if(!sol)continue;total++;
    const cell=cellMap.get(key(r,c)),val=(state[key(r,c)]||"").toUpperCase();cell.classList.remove("correct","wrong");
    if(!val){all=false;continue} if(val===sol){cell.classList.add("correct");correct++}else{cell.classList.add("wrong");all=false}}
  $("#progress").textContent=all?`Solved — ${total}/${total}`:`${correct}/${total} correct`;
}
function clearWrong(){document.querySelectorAll(".cell.wrong").forEach(cell=>{const k=cell.dataset.key;state[k]="";cell.querySelector("input").value="";cell.classList.remove("wrong")});saveState();updateProgress()}
function updateProgress(){let filled=0,total=0;for(const row of puzzle.grid)for(const ch of row)if(ch){total++;}for(const v of Object.values(state))if(v)filled++;$("#progress")?.replaceChildren(document.createTextNode(`${filled}/${total} filled`))}
async function share(){const text=`NewsGrid ${puzzle.date} — I played today’s news crossword.`;try{if(navigator.share)await navigator.share({title:"NewsGrid",text,url:location.href});else{await navigator.clipboard.writeText(`${text} ${location.href}`);$("#progress").textContent="Link copied"}}catch{}}

puzzle=ISSUE;state=loadState();render();
})();
